import json as j
import xml.etree.cElementTree as e
from collections import OrderedDict


def jsonConverter(inputfile, outputfile, startline, endline):
    # Reading in JSON file
    with open(inputfile) as json_format_file:
        d = j.load(json_format_file)

    # Creating the data for the XML file
    r = e.Element("Benchmark")
    entries = e.SubElement(r, "entries")

    # For every entry in the data set (title, entities, types, relations, abstract, abstract_og)
    for z in d:

        # Creating an ID for each entry
        key_index = list(d).index(z)
        eid = "Id" + str(key_index + 1)
        if endline > int(eid.replace("Id", "")) > startline:
            tags = OrderedDict([("size", "1"), ("eid", eid), ("category", "Science")])
            entry = e.SubElement(entries, "entry", tags)

            # Adding title element to the entry
            e.SubElement(entry, "title").text = z["title"]

            # Adding the original tripleset to the entry
            ots = e.SubElement(entry, "originaltripleset")
            # Adding in the root node and global relations
            counter = -1
            for f in z["entities"]:
                counter += 1
                otriple = e.SubElement(ots, "otriple")
                otriple.text = "Root | GLOBAL" + "_" + str(counter) + " | " + f
            # Adding in the extra relations
            for f in z["relations"]:
                ostring = str(
                    f.replace("-- USED-FOR --", "| USED-FOR |").replace("-- CONJUNCTION --", "| CONJUNCTION |").replace(
                        "-- FEATURE-OF --", "| FEATURE-OF |").replace("-- PART-OF --", "| PART-OF |").replace(
                        "-- COMPARE --", "| COMPARE |").replace("-- EVALUATE-FOR --", "| EVALUATE-FOR |").replace(
                        "-- HYPONYM-OF --", "| HYPONYM-OF |"))
                otriple.text = str(ostring)

            # Adding the modified tripleset to the entry
            mts = e.SubElement(entry, "modifiedtripleset")
            # Adding in the root node and global relations
            counter = -1
            for f in z["entities"]:
                counter += 1
                mtriple = e.SubElement(mts, "mtriple")
                mtriple.text = "Root | GLOBAL" + "_" + str(counter) + " | " + f
            # Adding in the extra relations
            for f in z["relations"]:
                mstring = str(
                    f.replace("-- USED-FOR --", "| USED-FOR |").replace("-- CONJUNCTION --", "| CONJUNCTION |").replace(
                        "-- FEATURE-OF --", "| FEATURE-OF |").replace("-- PART-OF --", "| PART-OF |").replace(
                        "-- COMPARE --", "| COMPARE |").replace("-- EVALUATE-FOR --", "| EVALUATE-FOR |").replace(
                        "-- HYPONYM-OF --", "| HYPONYM-OF |"))
                mtriple.text = str(mstring)
                tsize = str(len(mts))

            # Setting the size of the entry to match the number of triples in the entry
            entry.set("size", tsize)

            # Adding in the types
            e.SubElement(entry, "types").text = z["types"]

            # Adding the abstract to the entry
            e.SubElement(entry, "lex", {"lid": "Id1", "comment": "good"}).text = z["abstract_og"]

    # Creating the XML file
    a = e.ElementTree(r)
    a.write(outputfile)
    print(outputfile, " done!")


def main():

    jsonConverter("unprocessed.val.json", "agenda2/dev/1triples/val-agenda-1.xml", 0, 101)
    jsonConverter("unprocessed.val.json", "agenda2/dev/2triples/val-agenda-2.xml", 100, 201)
    jsonConverter("unprocessed.val.json", "agenda2/dev/3triples/val-agenda-3.xml", 200, 301)
    jsonConverter("unprocessed.val.json", "agenda2/dev/4triples/val-agenda-4.xml", 300, 401)
    jsonConverter("unprocessed.val.json", "agenda2/dev/5triples/val-agenda-5.xml", 400, 501)
    jsonConverter("unprocessed.val.json", "agenda2/dev/6triples/val-agenda-6.xml", 500, 601)
    jsonConverter("unprocessed.val.json", "agenda2/dev/7triples/val-agenda-7.xml", 600, 701)
    jsonConverter("unprocessed.val.json", "agenda2/dev/8triples/val-agenda-8.xml", 700, 801)
    jsonConverter("unprocessed.val.json", "agenda2/dev/9triples/val-agenda-9.xml", 800, 901)
    jsonConverter("unprocessed.val.json", "agenda2/dev/10triples/val-agenda-10.xml", 900, 1001)

    jsonConverter("unprocessed.train.json", "agenda2/train/1triples/train-agenda-1.xml", 0, 1001)
    jsonConverter("unprocessed.train.json", "agenda2/train/2triples/train-agenda-2.xml", 1000, 2001)
    jsonConverter("unprocessed.train.json", "agenda2/train/3triples/train-agenda-3.xml", 2000, 3001)
    jsonConverter("unprocessed.train.json", "agenda2/train/4triples/train-agenda-4.xml", 3000, 4001)
    jsonConverter("unprocessed.train.json", "agenda2/train/5triples/train-agenda-5.xml", 4000, 5001)
    jsonConverter("unprocessed.train.json", "agenda2/train/6triples/train-agenda-6.xml", 5000, 6001)
    jsonConverter("unprocessed.train.json", "agenda2/train/7triples/train-agenda-7.xml", 6000, 7001)
    jsonConverter("unprocessed.train.json", "agenda2/train/8triples/train-agenda-8.xml", 7000, 8001)
    jsonConverter("unprocessed.train.json", "agenda2/train/9triples/train-agenda-9.xml", 8000, 9001)
    jsonConverter("unprocessed.train.json", "agenda2/train/10triples/train-agenda-10.xml", 9000, 10001)

    jsonConverter("unprocessed.test.json", "agenda2/test/1triples/test-agenda-1.xml", 0, 101)
    jsonConverter("unprocessed.test.json", "agenda2/test/2triples/test-agenda-2.xml", 100, 201)
    jsonConverter("unprocessed.test.json", "agenda2/test/3triples/test-agenda-3.xml", 200, 301)
    jsonConverter("unprocessed.test.json", "agenda2/test/4triples/test-agenda-4.xml", 300, 401)
    jsonConverter("unprocessed.test.json", "agenda2/test/5triples/test-agenda-5.xml", 400, 501)
    jsonConverter("unprocessed.test.json", "agenda2/test/6triples/test-agenda-6.xml", 500, 601)
    jsonConverter("unprocessed.test.json", "agenda2/test/7triples/test-agenda-7.xml", 600, 701)
    jsonConverter("unprocessed.test.json", "agenda2/test/8triples/test-agenda-8.xml", 700, 801)
    jsonConverter("unprocessed.test.json", "agenda2/test/9triples/test-agenda-9.xml", 800, 901)
    jsonConverter("unprocessed.test.json", "agenda2/test/10triples/test-agenda-10.xml", 900, 1001)


if __name__ == "__main__":
    main()
